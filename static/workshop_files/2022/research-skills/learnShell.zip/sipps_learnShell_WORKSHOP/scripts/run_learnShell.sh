#!/bin/bash 

# Run a series of commands learned in the SIPPS Shell workshop
# By: YOUR NAME

# First, set up your current working directory as a variable
pwd=`pwd`

# Set up the parent directory sipps_learnShell, which is one level up
root_dir=$pwd/..

# Change directory to sipps_learnShell
cd "${root_dir}" 

# Remove the nonsense file
echo "Removing nonsense file."
rm $root_dir/nonsense.txt
echo "Removed!"


echo "Dealing with subjects 4-6..."

# Create text files for subs 5-6
for s in 0{05..06}; do 
    # Copy file from subject 4
    cp text_files/sub-04.txt text_files/sub-$s.txt
done

# Now, deal with directories for subs 4-6 
for i in 0{04..06}; do

    # Make the sub-directories for subs 4-6
    mkdir -p subs/sub-$i

    # Move the text files to their respective locations
    mv text_files/sub-$i.txt subs/sub-$i
done


echo "Now, rename a folder!"

# Lastly, rename our "script" folder
mv scripts code

echo "All done!"